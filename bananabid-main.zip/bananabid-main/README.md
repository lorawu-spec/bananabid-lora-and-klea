# bananabid test harness

Test your bots before submitting them!

Download the code by pressing the green code button and then download ZIP. If you're a little more experienced with git, feel free to clone.

To run: `python bananabid.py` and then choose relevant options.
To test your bot: name the file `<your bot name>.py` then copy it into the `bots/` directory. Make sure it has a function named `bananabid` and that the names of the arguments are exactly the same as they are in the spec.

Have fun! You can copy as many bots as you like into the bots directory. It comes preloaded with the default bots, so you can compare to them and see what works.
