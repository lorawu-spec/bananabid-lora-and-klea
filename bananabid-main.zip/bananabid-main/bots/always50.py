def bananabid(my_player_number, my_bananas, monkey_position, opponent_bananas, past_bid_list, turn_number):
	
	if my_bananas >= 50:
		return 50
	else:
		return 0